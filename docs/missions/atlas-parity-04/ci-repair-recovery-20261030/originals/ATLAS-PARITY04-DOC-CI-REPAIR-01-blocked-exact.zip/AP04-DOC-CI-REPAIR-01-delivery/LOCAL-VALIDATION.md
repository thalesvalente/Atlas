# Validação local do reparo AP04

## Resultado

- Patch aplica com `git apply --check --index`: **PASS**.
- Patch aplica com index contra os cinco blobs históricos exatos: **PASS**.
- Paths alterados/adicionados: **19 exatos**.
- `git diff --cached --check`: **PASS**.
- Compilação Python: **PASS**.
- Contraprovas normais: **17/17 PASS**.
- Contraprovas com `PYTHONOPTIMIZE=1` e `python -O`: **17/17 PASS**.
- YAML dos cinco workflows: **PASS**.
- JSON dos recibos: **PASS**.
- Overlay: **19 paths autorizados**.
- Manifesto: **18 entradas canônicas**, todas com SHA-256 válido; o próprio manifesto é excluído por autorreferência.
- Marcadores de bypass/roteamento por branch nos workflows: **ausentes**.
- `assert` Python removível por `-O` no novo guard/teste: **ausente**.
- Integração sintética completa: **PASS**, com 28 paths (`9 + 19`), cinco workflows e dez declarações C4 congeladas.

## Limites

A validação foi feita em ambiente Linux. O workflow novo declara Linux/Windows × normal/`-O`, mas essas quatro células não foram executadas no GitHub porque não houve SHA publicado. Também não foram executados os browsers reais, a suíte C4 de 168 IDs nem Spec Kit no reparo; esses resultados não são simulados.

A revisão adversarial foi feita pelo autor do delta e encontrou uma lacuna corrigida — proteção semântica de `ASSETS`, inputs e adaptador P03 —, mas não é revisão independente.

Consulte `logs/` para as saídas completas e `FULL-CONTRACT-INTEGRATION.json` para o resumo de integração.
