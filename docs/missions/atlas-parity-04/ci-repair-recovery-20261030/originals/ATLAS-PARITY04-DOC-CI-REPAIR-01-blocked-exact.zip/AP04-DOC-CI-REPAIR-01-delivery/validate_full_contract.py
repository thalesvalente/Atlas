from __future__ import annotations

from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile

PATCH_ROOT = Path('/mnt/data/ap04-repair/patch-root')
BASE_ROOT = Path('/mnt/data/ap04-repair/original-root')


def main() -> int:
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)

        def git(*args: str) -> str:
            return subprocess.check_output(['git', *args], cwd=root).decode().strip()

        def write(path: str, data: bytes | str) -> None:
            target = root / path
            target.parent.mkdir(parents=True, exist_ok=True)
            if isinstance(data, bytes):
                target.write_bytes(data)
            else:
                target.write_text(data, encoding='utf-8')

        subprocess.check_call(['git', 'init', '-q'], cwd=root)
        git('config', 'core.autocrlf', 'false')
        shutil.copytree(BASE_ROOT, root, dirs_exist_ok=True)
        write('docs/missions/atlas-parity-03/c4-full-convergence/MANIFEST.sha256',
              'synthetic frozen C4 manifest\n')
        write('packages/protocol/src/caderno_protocol/resources/schema.json', '{}\n')
        write('AGENTS.md', 'synthetic\n')
        git('add', '-A')
        subprocess.check_call([
            'git', '-c', 'user.name=Integration', '-c', 'user.email=i@example.invalid',
            'commit', '-qm', 'C4'], cwd=root)
        c4_sha = git('rev-parse', 'HEAD')
        c4_tree = git('rev-parse', 'HEAD^{tree}')

        spec = importlib.util.spec_from_file_location(
            'guard_build', PATCH_ROOT / 'scripts/qa/atlas_parity04_doc_ci.py')
        if spec is None or spec.loader is None:
            raise RuntimeError('Cannot load guard')
        guard = importlib.util.module_from_spec(spec)
        sys.modules['guard_build'] = guard
        spec.loader.exec_module(guard)

        for path in guard.DOC_PATHS:
            if path == guard.GATES_PATH:
                write(path, json.dumps({
                    'plan_id': 'AP04-POR-v1.0-draft',
                    'adr0003': 'PROPOSED_NOT_APPROVED',
                    'scope': 'DOCUMENTATION_ONLY',
                    'non_authorizations': ['merge_main', 'release', 'deploy', 'promotion'],
                }) + '\n')
            elif path == guard.ADR_PATH:
                write(path, '# ADR-0003\n\nPROPOSED_NOT_APPROVED\n')
            else:
                write(path, 'synthetic doc ' + path + '\n')
        git('add', '-A')
        subprocess.check_call([
            'git', '-c', 'user.name=Integration', '-c', 'user.email=i@example.invalid',
            'commit', '-qm', 'docs'], cwd=root)
        doc_sha = git('rev-parse', 'HEAD')
        doc_tree = git('rev-parse', 'HEAD^{tree}')

        for path in guard.REPAIR_PATHS:
            if path == guard.OVERLAY_MANIFEST:
                continue
            target = root / path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(PATCH_ROOT / path, target)
        overlay_path = root / guard.OVERLAY_CONTRACT
        overlay = json.loads(overlay_path.read_text(encoding='utf-8'))
        overlay['base_sha'] = c4_sha
        overlay['baseline_doc_sha'] = doc_sha
        overlay_path.write_text(json.dumps(overlay, indent=2, ensure_ascii=False) + '\n',
                                encoding='utf-8')
        lines = []
        for path in sorted(guard.REPAIR_PATHS - {guard.OVERLAY_MANIFEST}):
            lines.append(hashlib.sha256((root / path).read_bytes()).hexdigest() + '  ' + path)
        write(guard.OVERLAY_MANIFEST, '\n'.join(lines) + '\n')
        git('add', '-A')
        subprocess.check_call([
            'git', '-c', 'user.name=Integration', '-c', 'user.email=i@example.invalid',
            'commit', '-qm', 'repair'], cwd=root)

        contract = guard.SuccessorContract(
            c4_sha=c4_sha, c4_tree=c4_tree, doc_sha=doc_sha, doc_tree=doc_tree,
            doc_paths=guard.DOC_PATHS, repair_paths=guard.REPAIR_PATHS,
            modified_repair_paths=guard.MODIFIED_REPAIR_PATHS,
            adr_path=guard.ADR_PATH, gates_path=guard.GATES_PATH,
            c4_manifest=guard.C4_MANIFEST, overlay_contract=guard.OVERLAY_CONTRACT,
            overlay_manifest=guard.OVERLAY_MANIFEST,
        )
        report = guard.audit(
            root, contract=contract,
            boundary_audit=lambda *_: {
                'status': 'PASS_EXACT_SUCCESSOR_EXCEPTION',
                'historical_protection_weakened': False,
            },
        )
        summary = {
            'status': report['status'],
            'delta_count': report.get('complete_delta', {}).get('count'),
            'document_count': report.get('original_document_count'),
            'repair_path_count': len(guard.REPAIR_PATHS),
            'repair_commit_count': len(report.get('repair_history', [])),
            'workflow_count': len(report.get('workflow_safety', {})),
            'frozen_literals': report.get('c4_frozen_literals', {}).get('frozen_literals'),
            'error': report.get('error'),
        }
        print(json.dumps(summary, indent=2, ensure_ascii=False))
        return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
